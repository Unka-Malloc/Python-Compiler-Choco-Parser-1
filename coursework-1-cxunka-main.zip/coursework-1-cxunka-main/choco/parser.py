import traceback

from xdsl.dialects.builtin import ModuleOp

from choco.lexer import Token, TokenKind, Lexer
import choco.dialects.choco_ast as ast

from xdsl.ir import Operation
from typing import List, Union


class Parser:
    """
    A Simple ChocoPy Parser

    Parse the given tokens from the lexer and call the xDSL API to create an AST.
    """

    def __init__(self, lexer: Lexer):
        """
        Create a new parser.

        Initialize parser with the corresponding lexer.
        """
        self.lexer = lexer
        self.history = []
        self.file_name = str(self.lexer.tokenizer.scanner.stream.name)

    @property
    def file_lines(self) -> list:
        return open(self.file_name, 'r').readlines()

    def locate_now(self, next_line=False, some_more=0):
        hist_buf = [i for i in self.history]
        skip_line = []
        target_str = str(self.lexer.peek().value)

        start_pos = 0
        for lnum in range(len(self.file_lines)):
            if lnum in skip_line:
                continue
            if self.file_lines[lnum].strip().startswith('#'):
                continue
            this_line = self.file_lines[lnum]
            tok_in_line = []
            all_in_line = []
            for t in hist_buf:
                if t in this_line:
                    tok_in_line.append(t)
                    all_in_line.append(True)
                    try:
                        start_pos = this_line.index(t, start_pos)
                    except:
                        if this_line.index(t) < start_pos:
                            start_pos = 0
                            continue
                        else:
                            raise IndexError(f"IndexError: Incorrect start position {start_pos}, \n"
                                             f">>> can't locate {t} in substr [{this_line[start_pos:].rstrip()}], \n"
                                             f">>> line: [{this_line.rstrip()}], \n"
                                             f">>> history: {hist_buf}")
                else:
                    all_in_line.append(False)
                    break
            if all(all_in_line):
                row_pos = lnum + 1
                offset = start_pos + 1 + some_more

                if next_line:
                    row_pos += 1

                    next_line = self.file_lines[lnum + 1]

                    empty_count = lnum + 1
                    while not next_line.strip():
                        empty_count += 1
                        row_pos += 1
                        next_line = self.file_lines[empty_count]
                    col_pos = [i for i in range(len(next_line)) if next_line[i] != ' '][0] + 1
                    if self.check(TokenKind.INDENT):
                        if self.lexer.tokenizer.line_indent_lvl % 2 == 1:
                            col_pos -= 1
                        else:
                            col_pos -= self.lexer.tokenizer.line_indent_lvl

                    return row_pos, col_pos
                elif target_str == 'None':
                    col_pos = len(this_line)
                    return row_pos, col_pos
                elif target_str in this_line[offset:]:
                    col_pos = this_line.index(target_str, offset) + 1
                    return row_pos, col_pos
                else:
                    raise IndexError(f"IndexError: Incorrect offset {offset}, \n"
                                     f">>> can't locate {target_str} in substr {this_line[offset:].split()}, \n"
                                     f">>> line ({row_pos}): {this_line.split()}, \n"
                                     f">>> history: {hist_buf}")
            else:
                if all([i in ''.join(hist_buf) for i in this_line if i.strip()]):
                    skip_line.append(lnum)
                    for t in tok_in_line:
                        hist_buf.remove(t)
            start_pos = 0
        else:
            raise IndexError(f"Can't locate {self.lexer.peek().value} in {self.file_name}.")

    def check(self, expected: Union[List[TokenKind], TokenKind]) -> bool:
        """
        Check that the next token is of a given kind. If a list of n TokenKinds
        is given, check that the next n TokenKinds match the next expected
        ones.

        :param expected: The kind of the token we expect or a list of expected
                         token kinds if we look ahead more than one token at
                         a time.
        :returns: True if the next token has the expected token kind, False
￼                 otherwise.
        """

        if isinstance(expected, list):
            tokens = self.lexer.peek(len(expected))
            assert isinstance(tokens, list), "List of tokens expected"
            return all(
                [tok.kind == type_ for tok, type_ in zip(tokens, expected)])

        token = self.lexer.peek()
        assert isinstance(token, Token), "Single token expected"
        return token.kind == expected

    def match(self, expected: TokenKind) -> Token:
        """
        Match a token by first checking the token kind. In case the token is of
        the expected kind, we consume the token.  If a token with an unexpected
        token kind is encountered, an error is reported by raising an
        exception.

        The exception shows information about the line where the token was expected.

        :param expected: The kind of the token we expect.
        :returns: The consumed token if the next token has the expected token
                  kind, otherwise a parsing error is reported.
        """

        if self.check(expected):
            token = self.lexer.peek()
            assert isinstance(token, Token), "A single token expected"
            self.lexer.consume()
            if str(token.value) != 'None':
                self.history.append(str(token.value))
            return token

        token = self.lexer.peek()
        assert isinstance(token, Token), "A single token expected"
        print(f"Error: token of kind {expected} not found.")
        exit(0)

    def parse_program(self) -> ModuleOp:
        """
        Parse a ChocoPy program.

        program ::= def_seq stmt_seq EOF

        TODO: Not fully implemented.
        :returns: The AST of a ChocoPy Program.
        """
        defs = self.parse_def_seq()
        stmts = self.parse_stmt_seq()

        if self.check(TokenKind.EOF):
            self.match(TokenKind.EOF)

            return ModuleOp.from_region_or_ops([ast.Program.get(defs, stmts)])
        else:
            if self.check(TokenKind.INDENT):
                err_pos = self.locate_now(True)
                raise SyntaxError(
                    f'SyntaxError (line {err_pos[0]}, column {err_pos[1]}): '
                    f'Unexpected indentation.\n'
                    f'>>>{self.file_lines[err_pos[0] - 1].rstrip()}\n'
                    f'>>>{"-" * (err_pos[1] - 1)}^\n')
            raise NotImplementedError(f'Unexpected program token {self.lexer.peek()}')

    def is_def(self):
        if self.check(TokenKind.DEF):
            return True
        if self.check([TokenKind.IDENTIFIER, TokenKind.COLON]):
            return True
        if self.check(TokenKind.GLOBAL):
            return True
        if self.check(TokenKind.NONLOCAL):
            return True

    def parse_def_seq(self) -> List[Operation]:
        """
        Parse a sequence of function and variable definitions.

        def_seq ::= [func_def | var_def]*

        TODO: Not fully implemented.
        :returns: A list of function and variable definitions.
        """

        defs: List[Operation] = []

        while self.is_def():
            if self.check(TokenKind.DEF):
                func_def = self.parse_function()
                defs.append(func_def)

            if self.check([TokenKind.IDENTIFIER, TokenKind.COLON]):
                var_def = self.parse_variable()
                defs.append(var_def)

            if self.check(TokenKind.GLOBAL):
                self.match(TokenKind.GLOBAL)

                if self.check(TokenKind.IDENTIFIER):
                    id_name = self.match(TokenKind.IDENTIFIER).value
                else:
                    err_pos = self.locate_now()
                    raise SyntaxError(
                        f'SyntaxError (line {err_pos[0]}, column {err_pos[1]}): '
                        f'token of kind TokenKind.IDENTIFIER not found.\n'
                        f'>>>{self.file_lines[err_pos[0] - 1].rstrip()}\n'
                        f'>>>{"-" * (err_pos[1] - 1)}^\n')

                defs.append(ast.GlobalDecl.get(id_name))

                if self.check(TokenKind.NEWLINE):
                    self.match(TokenKind.NEWLINE)
                else:
                    err_pos = self.locate_now()
                    raise SyntaxError(
                        f'SyntaxError (line {err_pos[0]}, column {err_pos[1]}): '
                        f'token of kind TokenKind.NEWLINE not found.\n'
                        f'>>>{self.file_lines[err_pos[0] - 1].rstrip()}\n'
                        f'>>>{"-" * (err_pos[1] - 1)}^\n')

            if self.check(TokenKind.NONLOCAL):
                self.match(TokenKind.NONLOCAL)

                if self.check(TokenKind.IDENTIFIER):
                    id_name = self.match(TokenKind.IDENTIFIER).value
                else:
                    err_pos = self.locate_now()
                    raise SyntaxError(
                        f'SyntaxError (line {err_pos[0]}, column {err_pos[1]}): '
                        f'token of kind TokenKind.IDENTIFIER not found.\n'
                        f'>>>{self.file_lines[err_pos[0] - 1].rstrip()}\n'
                        f'>>>{"-" * (err_pos[1] - 1)}^\n')

                defs.append(ast.NonLocalDecl.get(id_name))

                if self.check(TokenKind.NEWLINE):
                    self.match(TokenKind.NEWLINE)
                else:
                    err_pos = self.locate_now()
                    raise SyntaxError(
                        f'SyntaxError (line {err_pos[0]}, column {err_pos[1]}): '
                        f'token of kind TokenKind.NEWLINE not found.\n'
                        f'>>>{self.file_lines[err_pos[0] - 1].rstrip()}\n'
                        f'>>>{"-" * (err_pos[1] - 1)}^\n')

        return defs

    def parse_function(self) -> Operation:
        """
        Parse a function definition.

                   func_def := `def` ID `(` `)` `:` NEWLINE INDENT func_body DEDENT
                  func_body := stmt_seq

        The above definition is incomplete.

        TODO: Not fully implemented.
        :return: Operation
        """
        self.match(TokenKind.DEF)

        function_name = self.match(TokenKind.IDENTIFIER)

        if self.check(TokenKind.LROUNDBRACKET):
            self.match(TokenKind.LROUNDBRACKET)
        else:
            err_pos = self.locate_now()
            raise SyntaxError(
                f'SyntaxError (line {err_pos[0]}, column {err_pos[1]}): '
                f'token of kind TokenKind.LROUNDBRACKET not found.\n'
                f'>>>{self.file_lines[err_pos[0] - 1].rstrip()}\n'
                f'>>>{"-" * (err_pos[1] - 1)}^\n')

        # Function parameters
        parameters: List[Operation] = []

        is_first_param = True
        while self.check([TokenKind.IDENTIFIER, TokenKind.COLON]):
            if self.check([TokenKind.IDENTIFIER, TokenKind.COLON]):
                if not is_first_param:
                    if self.check(TokenKind.COMMA):
                        self.match(TokenKind.COMMA)
                    else:
                        err_pos = self.locate_now()
                        raise SyntaxError(f'SyntaxError (line {err_pos[0]}, column {err_pos[1]}): expression found, '
                                          f'but comma expected.\n'
                                          f'>>>{self.file_lines[err_pos[0] - 1].rstrip()}\n'
                                          f'>>>{"-" * (err_pos[1] - 1)}^\n')

                var_name = self.match(TokenKind.IDENTIFIER).value

                if self.check(TokenKind.COLON):
                    self.match(TokenKind.COLON)
                else:
                    err_pos = self.locate_now()
                    raise SyntaxError(
                        f'SyntaxError (line {err_pos[0]}, column {err_pos[1]}): '
                        f'token of kind TokenKind.COLON not found.\n'
                        f'>>>{self.file_lines[err_pos[0] - 1].rstrip()}\n'
                        f'>>>{"-" * (err_pos[1] - 1)}^\n')

                if self.is_type():
                    type_expr = self.parse_type()
                else:
                    err_pos = self.locate_now()
                    raise SyntaxError(
                        f'SyntaxError (line {err_pos[0]}, column {err_pos[1]}): '
                        f'Unknown type.\n'
                        f'>>>{self.file_lines[err_pos[0] - 1].rstrip()}\n'
                        f'>>>{"-" * (err_pos[1] - 1)}^\n')

                typed_var = ast.TypedVar.get(var_name, type_expr)
                parameters.append(typed_var)
            else:
                raise NotImplementedError(f'Error: parse_variable() is used in a wrong place. '
                                          f'The first token should be {TokenKind.IDENTIFIER}, '
                                          f'and the second token should be {TokenKind.COLON}')

            is_first_param = False

        if self.check(TokenKind.RROUNDBRACKET):
            self.match(TokenKind.RROUNDBRACKET)
        else:
            err_pos = self.locate_now()
            raise SyntaxError(
                f'SyntaxError (line {err_pos[0]}, column {err_pos[1]}): '
                f'token of kind TokenKind.RROUNDBRACKET not found.\n'
                f'>>>{self.file_lines[err_pos[0] - 1].rstrip()}\n'
                f'>>>{"-" * (err_pos[1] - 1)}^\n')

        if self.check(TokenKind.RARROW):
            self.match(TokenKind.RARROW)

            if self.is_type():
                return_type = self.parse_type()
            else:
                err_pos = self.locate_now()
                raise SyntaxError(
                    f'SyntaxError (line {err_pos[0]}, column {err_pos[1]}): '
                    f'Unknown type.\n'
                    f'>>>{self.file_lines[err_pos[0] - 1].rstrip()}\n'
                    f'>>>{"-" * (err_pos[1] - 1)}^\n')
        else:
            # Return type: default is <None>.
            return_type = ast.TypeName.get('<None>')

        if self.check(TokenKind.COLON):
            self.match(TokenKind.COLON)
        else:
            err_pos = self.locate_now()
            raise SyntaxError(
                f'SyntaxError (line {err_pos[0]}, column {err_pos[1]}): '
                f'token of kind TokenKind.COLON not found.\n'
                f'>>>{self.file_lines[err_pos[0] - 1].rstrip()}\n'
                f'>>>{"-" * (err_pos[1] - 1)}^\n')
        if self.check(TokenKind.NEWLINE):
            self.match(TokenKind.NEWLINE)
        else:
            err_pos = self.locate_now()
            raise SyntaxError(
                f'SyntaxError (line {err_pos[0]}, column {err_pos[1]}): '
                f'token of kind TokenKind.NEWLINE not found.\n'
                f'>>>{self.file_lines[err_pos[0] - 1].rstrip()}\n'
                f'>>>{"-" * (err_pos[1] - 1)}^\n')

        if self.check(TokenKind.INDENT):
            self.match(TokenKind.INDENT)
        else:
            err_pos = self.locate_now(True)
            raise SyntaxError(
                f'SyntaxError (line {err_pos[0]}, column {err_pos[1]}): '
                f'expected at least one indented statement in function.\n'
                f'>>>{self.file_lines[err_pos[0] - 1].rstrip()}\n'
                f'>>>{"-" * (err_pos[1] - 1)}^\n')

        defs_and_decls: List[Operation] = self.parse_def_seq()

        stmt_seq = self.parse_stmt_seq()
        if not stmt_seq:
            if self.check(TokenKind.DEDENT):
                self.match(TokenKind.DEDENT)
            else:
                err_pos = self.locate_now(True)
                raise SyntaxError(
                    f'SyntaxError (line {err_pos[0]}, column {err_pos[1]}): '
                    f'Unexpected indentation.\n'
                    f'>>>{self.file_lines[err_pos[0] - 1].rstrip()}\n'
                    f'>>>{"-" * (err_pos[1] - 1)}^\n')
            if self.is_stmt_first_set():
                err_pos = self.locate_now(True)
                raise SyntaxError(
                    f'SyntaxError (line {err_pos[0]}, column {err_pos[1]}): '
                    f'expected at least one indented statement in function.\n'
                    f'>>>{self.file_lines[err_pos[0] - 1].rstrip()}\n'
                    f'>>>{"-" * (err_pos[1] - 1)}^\n')
            if self.check(TokenKind.INDENT):
                err_pos = self.locate_now(True)
                raise SyntaxError(
                    f'SyntaxError (line {err_pos[0]}, column {err_pos[1]}): '
                    f'Unexpected indentation.\n'
                    f'>>>{self.file_lines[err_pos[0] - 1].rstrip()}\n'
                    f'>>>{"-" * (err_pos[1] - 1)}^\n')
            raise Exception(
                'Error: Function body should have at least one statement.')

        if self.check(TokenKind.DEDENT):
            self.match(TokenKind.DEDENT)
        else:
            err_pos = self.locate_now(True)
            raise SyntaxError(
                f'SyntaxError (line {err_pos[0]}, column {err_pos[1]}): '
                f'Unexpected indentation.\n'
                f'>>>{self.file_lines[err_pos[0] - 1].rstrip()}\n'
                f'>>>{"-" * (err_pos[1] - 1)}^\n')

        func_body = defs_and_decls + stmt_seq

        return ast.FuncDef.get(function_name.value, parameters, return_type,
                               func_body)

    def parse_variable(self) -> Operation:
        if self.check([TokenKind.IDENTIFIER, TokenKind.COLON]):
            var_name = self.match(TokenKind.IDENTIFIER).value
            self.match(TokenKind.COLON)

            if self.is_type():
                type_expr = self.parse_type()
            else:
                err_pos = self.locate_now()
                raise SyntaxError(
                    f'SyntaxError (line {err_pos[0]}, column {err_pos[1]}): '
                    f'Unknown type.\n'
                    f'>>>{self.file_lines[err_pos[0] - 1].rstrip()}\n'
                    f'>>>{"-" * (err_pos[1] - 1)}^\n')

            if self.check(TokenKind.ASSIGN):
                self.match(TokenKind.ASSIGN)
            else:
                err_pos = self.locate_now()
                raise SyntaxError(
                    f'SyntaxError (line {err_pos[0]}, column {err_pos[1]}): '
                    f'token of kind TokenKind.ASSIGN not found.\n'
                    f'>>>{self.file_lines[err_pos[0] - 1].rstrip()}\n'
                    f'>>>{"-" * (err_pos[1] - 1)}^\n')

            if self.is_literal():
                literal_expr = self.parse_literal()
            else:
                raise NotImplementedError(f'Error: Expecting literal as next token, '
                                          f'but got {self.lexer.peek()}')

            if self.check(TokenKind.NEWLINE):
                self.match(TokenKind.NEWLINE)
            else:
                err_pos = self.locate_now()
                raise SyntaxError(
                    f'SyntaxError (line {err_pos[0]}, column {err_pos[1]}): '
                    f'token of kind TokenKind.NEWLINE not found.\n'
                    f'>>>{self.file_lines[err_pos[0] - 1].rstrip()}\n'
                    f'>>>{"-" * (err_pos[1] - 1)}^\n')

            return ast.VarDef.get(ast.TypedVar.get(var_name, type_expr), literal_expr)
        else:
            raise NotImplementedError(f'Error: parse_variable() is used in a wrong place. '
                                      f'The first token should be {TokenKind.IDENTIFIER}, '
                                      f'and the second token should be {TokenKind.COLON}')

    def is_type(self):
        if self.check(TokenKind.OBJECT):
            return True
        if self.check(TokenKind.INT):
            return True
        if self.check(TokenKind.BOOL):
            return True
        if self.check(TokenKind.STR):
            return True
        if self.check(TokenKind.LSQUAREBRACKET):
            return True

        return False

    def parse_type(self) -> Operation:
        if self.check(TokenKind.OBJECT):
            self.match(TokenKind.OBJECT)
            return ast.TypeName.get('object')
        if self.check(TokenKind.INT):
            self.match(TokenKind.INT)
            return ast.TypeName.get('int')
        if self.check(TokenKind.BOOL):
            self.match(TokenKind.BOOL)
            return ast.TypeName.get('bool')
        if self.check(TokenKind.STR):
            self.match(TokenKind.STR)
            return ast.TypeName.get('str')
        if self.check(TokenKind.LSQUAREBRACKET):
            self.match(TokenKind.LSQUAREBRACKET)
            if self.is_type():
                type_expr = self.parse_type()

                if self.check(TokenKind.RSQUAREBRACKET):
                    self.match(TokenKind.RSQUAREBRACKET)
                else:
                    err_pos = self.locate_now()
                    raise SyntaxError(
                        f'SyntaxError (line {err_pos[0]}, column {err_pos[1]}): '
                        f'token of kind TokenKind.RSQUAREBRACKET not found.\n'
                        f'>>>{self.file_lines[err_pos[0] - 1].rstrip()}\n'
                        f'>>>{"-" * (err_pos[1] - 1)}^\n')

                return ast.ListType.get(type_expr)
            else:
                err_pos = self.locate_now()
                raise SyntaxError(
                    f'SyntaxError (line {err_pos[0]}, column {err_pos[1]}): '
                    f'Unknown type.\n'
                    f'>>>{self.file_lines[err_pos[0] - 1].rstrip()}\n'
                    f'>>>{"-" * (err_pos[1] - 1)}^\n')

        err_pos = self.locate_now()
        raise SyntaxError(
            f'SyntaxError (line {err_pos[0]}, column {err_pos[1]}): '
            f'Unknown type.\n'
            f'>>>{self.file_lines[err_pos[0] - 1].rstrip()}\n'
            f'>>>{"-" * (err_pos[1] - 1)}^\n')

    def is_stmt_first_set(self) -> bool:
        """
        Check if the next token is in the first set of a statement.

        TODO: Not fully implemented.
        """

        if self.is_simple_stmt_first_set():
            return True

        if self.check(TokenKind.IF):
            return True

        if self.check(TokenKind.WHILE):
            return True

        if self.check(TokenKind.FOR):
            return True

        return False

    def parse_stmt(self) -> Operation:
        """ Parse a statement.

        stmt := simple_stmt NEWLINE

        The above definition is incomplete.

        TODO: Not fully implemented.
        :return: Statement as operation
        """

        if self.is_simple_stmt_first_set():
            simple_stmt = self.parse_simple_stmt()
            if self.check(TokenKind.RROUNDBRACKET):
                err_pos = self.locate_now(some_more=1)
                raise SyntaxError(
                    f'SyntaxError (line {err_pos[0]}, column {err_pos[1]}): '
                    f"unmatched ')'.\n"
                    f'>>>{self.file_lines[err_pos[0] - 1].rstrip()}\n'
                    f'>>>{"-" * (err_pos[1] - 1)}^\n')
            if self.check(TokenKind.COLON):
                err_pos = self.locate_now()
                raise SyntaxError(
                    f'SyntaxError (line {err_pos[0]}, column {err_pos[1]}): '
                    f"Variable declaration after non-declaration statement.\n"
                    f'>>>{self.file_lines[err_pos[0] - 1].rstrip()}\n'
                    f'>>>{"-" * (err_pos[1] - 1)}^\n')

            if self.check(TokenKind.NEWLINE):
                self.match(TokenKind.NEWLINE)
            else:
                err_pos = self.locate_now()
                raise SyntaxError(
                    f'SyntaxError (line {err_pos[0]}, column {err_pos[1]}): '
                    f'token of kind TokenKind.NEWLINE not found.\n'
                    f'>>>{self.file_lines[err_pos[0] - 1].rstrip()}\n'
                    f'>>>{"-" * (err_pos[1] - 1)}^\n')

            return simple_stmt
        if self.check(TokenKind.IF):
            self.match(TokenKind.IF)
            if self.is_expr_first_set():
                if_cond = self.parse_expr()
                if self.check(TokenKind.COLON):
                    self.match(TokenKind.COLON)
                    if self.is_block_first_set():
                        if_block = self.parse_block()

                        elif_list = []
                        while self.check(TokenKind.ELIF):
                            self.match(TokenKind.ELIF)

                            if self.is_expr_first_set():
                                elif_cond = self.parse_expr()
                            else:
                                err_pos = self.locate_now()
                                raise SyntaxError(
                                    f'SyntaxError (line {err_pos[0]}, column {err_pos[1]}): '
                                    f'Expected expression.\n'
                                    f'>>>{self.file_lines[err_pos[0] - 1].rstrip()}\n'
                                    f'>>>{"-" * (err_pos[1] - 1)}^\n')

                            if self.check(TokenKind.COLON):
                                self.match(TokenKind.COLON)
                            else:
                                err_pos = self.locate_now()
                                raise SyntaxError(
                                    f'SyntaxError (line {err_pos[0]}, column {err_pos[1]}): '
                                    f'token of kind TokenKind.COLON not found.\n'
                                    f'>>>{self.file_lines[err_pos[0] - 1].rstrip()}\n'
                                    f'>>>{"-" * (err_pos[1] - 1)}^\n')

                            if self.is_block_first_set():
                                elif_block = self.parse_block()
                            else:
                                err_pos = self.locate_now(True)
                                raise SyntaxError(
                                    f'SyntaxError (line {err_pos[0]}, column {err_pos[1]}): '
                                    f'expected at least one indented statement in block.\n'
                                    f'>>>{self.file_lines[err_pos[0] - 1].rstrip()}\n'
                                    f'>>>{"-" * (err_pos[1] - 1)}^\n')

                            elif_list.append((elif_cond, elif_block))

                        else_list = []
                        else_count = 0
                        while self.check(TokenKind.ELSE):
                            if else_count > 1:
                                raise NotImplementedError(f'Unexpected multi else blocks.')

                            self.match(TokenKind.ELSE)

                            if self.check(TokenKind.COLON):
                                self.match(TokenKind.COLON)
                            else:
                                err_pos = self.locate_now()
                                raise SyntaxError(
                                    f'SyntaxError (line {err_pos[0]}, column {err_pos[1]}): '
                                    f'token of kind TokenKind.COLON not found.\n'
                                    f'>>>{self.file_lines[err_pos[0] - 1].rstrip()}\n'
                                    f'>>>{"-" * (err_pos[1] - 1)}^\n')

                            if self.is_block_first_set():
                                else_block = self.parse_block()
                            else:
                                err_pos = self.locate_now(True)
                                raise SyntaxError(
                                    f'SyntaxError (line {err_pos[0]}, column {err_pos[1]}): '
                                    f'expected at least one indented statement in block.\n'
                                    f'>>>{self.file_lines[err_pos[0] - 1].rstrip()}\n'
                                    f'>>>{"-" * (err_pos[1] - 1)}^\n')

                            else_list.append(else_block)

                            else_count += 1

                        if_then = if_block

                        if_orelse = []

                        if else_list:
                            the_only_else_block = else_list[0]
                        else:
                            the_only_else_block = None

                        if the_only_else_block:
                            if elif_list:
                                nested_elif_else = ast.If.get(else_list[-1][0], else_list[-1][1], the_only_else_block)
                                for i in reversed(elif_list):
                                    nested_elif_else = ast.If.get(i[0], i[1], nested_elif_else)

                                if_orelse.append(nested_elif_else)
                            else:
                                if_orelse.append(the_only_else_block)

                        return ast.If.get(if_cond, if_then, if_orelse)
                    else:
                        if not self.check(TokenKind.NEWLINE):
                            err_pos = self.locate_now()
                            raise SyntaxError(
                                f'SyntaxError (line {err_pos[0]}, column {err_pos[1]}): '
                                f'token of kind TokenKind.NEWLINE not found.\n'
                                f'>>>{self.file_lines[err_pos[0] - 1].rstrip()}\n'
                                f'>>>{"-" * (err_pos[1] - 1)}^\n')

                        err_pos = self.locate_now(True)
                        raise SyntaxError(
                            f'SyntaxError (line {err_pos[0]}, column {err_pos[1]}): '
                            f'expected at least one indented statement in block.\n'
                            f'>>>{self.file_lines[err_pos[0] - 1].rstrip()}\n'
                            f'>>>{"-" * (err_pos[1] - 1)}^\n')
                else:
                    err_pos = self.locate_now()
                    raise SyntaxError(
                        f'SyntaxError (line {err_pos[0]}, column {err_pos[1]}): '
                        f'token of kind TokenKind.COLON not found.\n'
                        f'>>>{self.file_lines[err_pos[0] - 1].rstrip()}\n'
                        f'>>>{"-" * (err_pos[1] - 1)}^\n')
            else:
                err_pos = self.locate_now()
                raise SyntaxError(
                    f'SyntaxError (line {err_pos[0]}, column {err_pos[1]}): '
                    f'Expected expression.\n'
                    f'>>>{self.file_lines[err_pos[0] - 1].rstrip()}\n'
                    f'>>>{"-" * (err_pos[1] - 1)}^\n')

        if self.check(TokenKind.WHILE):
            self.match(TokenKind.WHILE)
            if self.is_expr_first_set():
                while_cond = self.parse_expr()
            else:
                err_pos = self.locate_now()
                raise SyntaxError(
                    f'SyntaxError (line {err_pos[0]}, column {err_pos[1]}): '
                    f'Expected expression.\n'
                    f'>>>{self.file_lines[err_pos[0] - 1].rstrip()}\n'
                    f'>>>{"-" * (err_pos[1] - 1)}^\n')

            if self.check(TokenKind.COLON):
                self.match(TokenKind.COLON)
            else:
                err_pos = self.locate_now()
                raise SyntaxError(
                    f'SyntaxError (line {err_pos[0]}, column {err_pos[1]}): '
                    f'token of kind TokenKind.COLON not found.\n'
                    f'>>>{self.file_lines[err_pos[0] - 1].rstrip()}\n'
                    f'>>>{"-" * (err_pos[1] - 1)}^\n')

            if self.is_block_first_set():
                while_block = self.parse_block()
            else:
                err_pos = self.locate_now(True)
                raise SyntaxError(
                    f'SyntaxError (line {err_pos[0]}, column {err_pos[1]}): '
                    f'expected at least one indented statement in block.\n'
                    f'>>>{self.file_lines[err_pos[0] - 1].rstrip()}\n'
                    f'>>>{"-" * (err_pos[1] - 1)}^\n')

            return ast.While.get(while_cond, while_block)

        if self.check(TokenKind.FOR):
            self.match(TokenKind.FOR)
            if self.check(TokenKind.IDENTIFIER):
                for_id = self.match(TokenKind.IDENTIFIER).value
            else:
                err_pos = self.locate_now()
                raise SyntaxError(
                    f'SyntaxError (line {err_pos[0]}, column {err_pos[1]}): '
                    f'token of kind TokenKind.IDENTIFIER not found.\n'
                    f'>>>{self.file_lines[err_pos[0] - 1].rstrip()}\n'
                    f'>>>{"-" * (err_pos[1] - 1)}^\n')

            if self.check(TokenKind.IN):
                self.match(TokenKind.IN)
            else:
                err_pos = self.locate_now()
                raise SyntaxError(
                    f'SyntaxError (line {err_pos[0]}, column {err_pos[1]}): '
                    f'token of kind TokenKind.IN not found.\n'
                    f'>>>{self.file_lines[err_pos[0] - 1].rstrip()}\n'
                    f'>>>{"-" * (err_pos[1] - 1)}^\n')

            if self.is_expr_first_set():
                for_expr = self.parse_expr()
            else:
                err_pos = self.locate_now()
                raise SyntaxError(
                    f'SyntaxError (line {err_pos[0]}, column {err_pos[1]}): '
                    f'Expected expression.\n'
                    f'>>>{self.file_lines[err_pos[0] - 1].rstrip()}\n'
                    f'>>>{"-" * (err_pos[1] - 1)}^\n')

            if self.check(TokenKind.COLON):
                self.match(TokenKind.COLON)
            else:
                err_pos = self.locate_now()
                raise SyntaxError(
                    f'SyntaxError (line {err_pos[0]}, column {err_pos[1]}): '
                    f'token of kind TokenKind.COLON not found.\n'
                    f'>>>{self.file_lines[err_pos[0] - 1].rstrip()}\n'
                    f'>>>{"-" * (err_pos[1] - 1)}^\n')

            if self.is_block_first_set():
                for_block = self.parse_block()
            else:
                err_pos = self.locate_now(True)
                raise SyntaxError(
                    f'SyntaxError (line {err_pos[0]}, column {err_pos[1]}): '
                    f'expected at least one indented statement in block.\n'
                    f'>>>{self.file_lines[err_pos[0] - 1].rstrip()}\n'
                    f'>>>{"-" * (err_pos[1] - 1)}^\n')

            return ast.For.get(for_id, for_expr, for_block)

        raise NotImplementedError(f'Not implemented: {self.lexer.peek()}')

    def parse_stmt_seq(self) -> List[Operation]:
        """ Parse a sequence of statements.

        stmt_seq := stmt stmt_seq

        :return: list of Operations
        """
        stmt_seq: List[Operation] = []
        while self.is_stmt_first_set():
            stmt_op = self.parse_stmt()
            stmt_seq.append(stmt_op)
        return stmt_seq

    def is_simple_stmt_first_set(self) -> bool:
        # pass
        if self.check(TokenKind.PASS):
            return True

        # expr
        # [expr `=`]+ expr
        if self.is_expr_first_set():
            return True

        if self.check(TokenKind.ASSIGN):
            err_pos = self.locate_now(True)
            raise SyntaxError(
                f'SyntaxError (line {err_pos[0]}, column {err_pos[1]}): '
                f'No left-hand side in assign statement.\n'
                f'>>>{self.file_lines[err_pos[0] - 1].rstrip()}\n'
                f'>>>{"-" * (err_pos[1] - 1)}^\n')

        # `return` [expr]?
        if self.check(TokenKind.RETURN):
            return True

        return False

    def parse_simple_stmt(self) -> Operation:
        """ Parse a simple statement.

        stmt := `pass`

        The above definition is incomplete.

        TODO: Not fully implemented.
        :return: Statement as operation
        """

        # `pass`
        if self.check(TokenKind.PASS):
            self.match(TokenKind.PASS)
            return ast.Pass.get()

        # `not` expr
        if self.check(TokenKind.NOT):
            self.match(TokenKind.NOT)

            if self.is_expr_first_set():
                expr = self.parse_expr()

                return ast.UnaryExpr.get('not', expr)
            else:
                err_pos = self.locate_now()
                raise SyntaxError(
                    f'SyntaxError (line {err_pos[0]}, column {err_pos[1]}): '
                    f'Expected expression.\n'
                    f'>>>{self.file_lines[err_pos[0] - 1].rstrip()}\n'
                    f'>>>{"-" * (err_pos[1] - 1)}^\n')

        # `return` [expr]?
        if self.check(TokenKind.RETURN):
            self.match(TokenKind.RETURN)
            if self.is_expr_first_set():
                return ast.Return.get(self.parse_expr())
            else:
                return ast.Return.get(None)

        # expr
        # [expr `=`]+ expr
        # expr `and` expr
        # expr `or` expr
        # expr `if` expr `else` expr
        if self.is_expr_first_set():
            # expr
            # [expr `=`]+ expr
            expr_first = self.parse_expr()

            if self.check(TokenKind.ASSIGN):
                # [expr `=`]+ expr
                expr_list = [expr_first]

                self.match(TokenKind.ASSIGN)

                while self.is_expr_first_set():
                    expr_next = self.parse_expr()
                    expr_list.append(expr_next)
                    if self.check(TokenKind.ASSIGN):
                        self.match(TokenKind.ASSIGN)
                    else:
                        if self.is_expr_first_set():
                            # More than one Assign
                            expr_last = self.parse_expr()
                            expr_list.append(expr_last)
                        elif self.check(TokenKind.NEWLINE):
                            # Only one Assign
                            break
                        else:
                            err_pos = self.locate_now()
                            raise SyntaxError(
                                f'SyntaxError (line {err_pos[0]}, column {err_pos[1]}): '
                                f'Expected expression.\n'
                                f'>>>{self.file_lines[err_pos[0] - 1].rstrip()}\n'
                                f'>>>{"-" * (err_pos[1] - 1)}^\n')

                if len(expr_list) < 2:
                    raise NotImplementedError(f'Error: Expecting multiple expr for assign, '
                                              f'but got {len(expr_list)}')
                elif len(expr_list) == 2:
                    return ast.Assign.get(expr_list[-2], expr_list[-1])
                else:
                    result = ast.Assign.get(expr_list[-2], expr_list[-1])
                    for expr in reversed(expr_list[:-2]):
                        result = ast.Assign.get(expr, result)
                    return result

            # expr `and` expr
            elif self.check(TokenKind.AND):
                bin_op = self.match(TokenKind.AND).value

                if self.is_expr_first_set():
                    expr_next = self.parse_expr()

                    return ast.BinaryExpr.get(bin_op, expr_first, expr_next)
                else:
                    err_pos = self.locate_now()
                    raise SyntaxError(
                        f'SyntaxError (line {err_pos[0]}, column {err_pos[1]}): '
                        f'Expected expression.\n'
                        f'>>>{self.file_lines[err_pos[0] - 1].rstrip()}\n'
                        f'>>>{"-" * (err_pos[1] - 1)}^\n')
            # expr `or` expr
            elif self.check(TokenKind.OR):
                bin_op = self.match(TokenKind.OR).value

                if self.is_expr_first_set():
                    expr_next = self.parse_expr()

                    return ast.BinaryExpr.get(bin_op, expr_first, expr_next)
                else:
                    err_pos = self.locate_now()
                    raise SyntaxError(
                        f'SyntaxError (line {err_pos[0]}, column {err_pos[1]}): '
                        f'Expected expression.\n'
                        f'>>>{self.file_lines[err_pos[0] - 1].rstrip()}\n'
                        f'>>>{"-" * (err_pos[1] - 1)}^\n')

            # expr `if` expr `else` expr
            elif self.check(TokenKind.IF):
                self.match(TokenKind.IF)

                if self.is_expr_first_set():
                    cond_expr = self.parse_expr()
                else:
                    err_pos = self.locate_now()
                    raise SyntaxError(
                        f'SyntaxError (line {err_pos[0]}, column {err_pos[1]}): '
                        f'Expected expression.\n'
                        f'>>>{self.file_lines[err_pos[0] - 1].rstrip()}\n'
                        f'>>>{"-" * (err_pos[1] - 1)}^\n')

                if self.check(TokenKind.ELSE):
                    self.match(TokenKind.ELSE)
                else:
                    err_pos = self.locate_now()
                    raise SyntaxError(
                        f'SyntaxError (line {err_pos[0]}, column {err_pos[1]}): '
                        f'token of kind TokenKind.ELSE not found.\n'
                        f'>>>{self.file_lines[err_pos[0] - 1].rstrip()}\n'
                        f'>>>{"-" * (err_pos[1] - 1)}^\n')

                if self.is_expr_first_set():
                    expr_default = self.parse_expr()
                else:
                    err_pos = self.locate_now()
                    raise SyntaxError(
                        f'SyntaxError (line {err_pos[0]}, column {err_pos[1]}): '
                        f'Expected expression.\n'
                        f'>>>{self.file_lines[err_pos[0] - 1].rstrip()}\n'
                        f'>>>{"-" * (err_pos[1] - 1)}^\n')

                return ast.IfExpr.get(cond_expr, expr_first, expr_default)

            # expr
            else:
                return expr_first

    def is_expr_first_set(self) -> bool:
        """
        Check if the next token is in the first set of an expression.

        TODO: Not fully implemented.
        """

        # cexpr
        if self.is_cexpr_first_set():
            return True

        # `not` expr
        if self.check(TokenKind.NOT):
            return True

        return False

    def parse_expr(self) -> Operation:
        if self.is_expr_first_set():
            if self.is_cexpr_first_set():
                cexpr_first = self.parse_cexpr()

                if self.is_bin_op():
                    # cexpr bin_op cexpr
                    bin_op = self.parse_bin_op()

                    if self.is_cexpr_first_set():
                        cexpr_second = self.parse_cexpr()
                    else:
                        err_pos = self.locate_now()
                        raise SyntaxError(
                            f'SyntaxError (line {err_pos[0]}, column {err_pos[1]}): '
                            f'Expected expression.\n'
                            f'>>>{self.file_lines[err_pos[0] - 1].rstrip()}\n'
                            f'>>>{"-" * (err_pos[1] - 1)}^\n')

                    binary_expr = ast.BinaryExpr.get(bin_op, cexpr_first, cexpr_second)

                    if bin_op in ['>', '>=', '==', '!=', '<=', '<']:
                        if self.check(TokenKind.LT) \
                                or self.check(TokenKind.LE) \
                                or self.check(TokenKind.EQ) \
                                or self.check(TokenKind.GE) \
                                or self.check(TokenKind.GT) \
                                or self.check(TokenKind.NE):
                            err_pos = self.locate_now()
                            raise SyntaxError(
                                f'SyntaxError (line {err_pos[0]}, column {err_pos[1]}): Comparison operators are not associative.\n'
                                f'>>>{self.file_lines[err_pos[0] - 1].rstrip()}\n'
                                f'>>>{"-" * (err_pos[1] - 1)}^\n')

                    while self.is_bin_op():
                        bin_op = self.parse_bin_op()

                        if self.is_cexpr_first_set():
                            cexpr_next = self.parse_cexpr()
                            binary_expr = ast.BinaryExpr.get(bin_op, binary_expr, cexpr_next)
                        else:
                            err_pos = self.locate_now()
                            raise SyntaxError(
                                f'SyntaxError (line {err_pos[0]}, column {err_pos[1]}): '
                                f'Expected expression.\n'
                                f'>>>{self.file_lines[err_pos[0] - 1].rstrip()}\n'
                                f'>>>{"-" * (err_pos[1] - 1)}^\n')

                    return binary_expr
                else:
                    # cexpr
                    return cexpr_first
            if self.check(TokenKind.NOT):
                unary_expr = self.match(TokenKind.NOT)

                next_expr = self.parse_expr()

                return ast.UnaryExpr.get(unary_expr.value, next_expr)
        else:
            err_pos = self.locate_now()
            raise SyntaxError(
                f'SyntaxError (line {err_pos[0]}, column {err_pos[1]}): '
                f'Expected expression.\n'
                f'>>>{self.file_lines[err_pos[0] - 1].rstrip()}\n'
                f'>>>{"-" * (err_pos[1] - 1)}^\n')

    def is_cexpr_first_set(self) -> bool:
        # ID
        # ID `(` [expr [`,` expr]*]? `)`
        if self.check(TokenKind.IDENTIFIER):
            return True

        # literal
        if self.is_literal():
            return True

        # `[` [expr [`,` expr]*]? `]`
        if self.check(TokenKind.LSQUAREBRACKET):
            return True

        # `(` expr `)`
        if self.check(TokenKind.LROUNDBRACKET):
            return True

        # `-` cexpr
        if self.check(TokenKind.MINUS):
            return True

        # cexpr `[` expr `]`
        # cexpr bin_op cexpr

        return False

    def parse_cexpr(self) -> Operation:
        if self.is_cexpr_first_set():
            # cexpr `[` expr `]`
            # cexpr bin_op cexpr

            # ID
            # ID `(` [expr [`,` expr]*]? `)`
            if self.check(TokenKind.IDENTIFIER):
                id_token = self.match(TokenKind.IDENTIFIER)
                id_expr = ast.ExprName.get(id_token.value)

                if self.check(TokenKind.LROUNDBRACKET):
                    self.match(TokenKind.LROUNDBRACKET)

                    if self.is_expr_first_set():
                        expr_first = self.parse_expr()

                        expr_list = []
                        while self.is_expr_first_set():
                            if self.check(TokenKind.COMMA):
                                self.match(TokenKind.COMMA)

                                expr_next = self.parse_expr()

                                expr_list.append(expr_next)
                            else:
                                err_pos = self.locate_now()
                                raise SyntaxError(
                                    f'SyntaxError (line {err_pos[0]}, column {err_pos[1]}): expression found, '
                                    f'but comma expected.\n'
                                    f'>>>{self.file_lines[err_pos[0] - 1].rstrip()}\n'
                                    f'>>>{"-" * (err_pos[1] - 1)}^\n')

                        if expr_list:
                            result = ast.CallExpr.get(id_token.value, [expr_first] + expr_list)
                        else:
                            result = ast.CallExpr.get(id_token.value, [expr_first])
                    else:
                        result = ast.CallExpr.get(id_token.value, [])

                    if self.check(TokenKind.RROUNDBRACKET):
                        self.match(TokenKind.RROUNDBRACKET)
                    else:
                        err_pos = self.locate_now()
                        raise SyntaxError(
                            f'SyntaxError (line {err_pos[0]}, column {err_pos[1]}): '
                            f'token of kind TokenKind.RROUNDBRACKET not found.\n'
                            f'>>>{self.file_lines[err_pos[0] - 1].rstrip()}\n'
                            f'>>>{"-" * (err_pos[1] - 1)}^\n')
                else:
                    result = id_expr
            elif self.is_literal():
                result = self.parse_literal()
            elif self.check(TokenKind.MINUS):
                minus = self.match(TokenKind.MINUS).value
                if self.is_cexpr_first_set():
                    cexpr = self.parse_cexpr()
                    result = ast.UnaryExpr.get(minus, cexpr)
                else:
                    err_pos = self.locate_now()
                    raise SyntaxError(
                        f'SyntaxError (line {err_pos[0]}, column {err_pos[1]}): '
                        f'Expected expression.\n'
                        f'>>>{self.file_lines[err_pos[0] - 1].rstrip()}\n'
                        f'>>>{"-" * (err_pos[1] - 1)}^\n')

            # `[` [expr [`,` expr]*]? `]`
            elif self.check(TokenKind.LSQUAREBRACKET):
                self.match(TokenKind.LSQUAREBRACKET)

                if self.is_expr_first_set():
                    expr_first = self.parse_expr()

                    expr_list = []
                    while self.check(TokenKind.COMMA):
                        self.match(TokenKind.COMMA)

                        expr_next = self.parse_expr()

                        expr_list.append(expr_next)
                    else:
                        if self.check(TokenKind.RSQUAREBRACKET):
                            self.match(TokenKind.RSQUAREBRACKET)
                        else:
                            if self.is_expr_first_set():
                                err_pos = self.locate_now()
                                raise SyntaxError(
                                    f'SyntaxError (line {err_pos[0]}, column {err_pos[1]}): expression found, '
                                    f'but comma expected.\n'
                                    f'>>>{self.file_lines[err_pos[0] - 1].rstrip()}\n'
                                    f'>>>{"-" * (err_pos[1] - 1)}^\n')

                            err_pos = self.locate_now()
                            raise SyntaxError(
                                f'SyntaxError (line {err_pos[0]}, column {err_pos[1]}): '
                                f'token of kind TokenKind.RSQUAREBRACKET not found.\n'
                                f'>>>{self.file_lines[err_pos[0] - 1].rstrip()}\n'
                                f'>>>{"-" * (err_pos[1] - 1)}^\n')

                    if expr_list:
                        result = ast.ListExpr.get([expr_first] + expr_list)
                    else:
                        result = ast.ListExpr.get([expr_first])
                else:
                    result = ast.ListExpr.get([])

                    if self.check(TokenKind.RSQUAREBRACKET):
                        self.match(TokenKind.RSQUAREBRACKET)
                    else:
                        err_pos = self.locate_now()
                        raise SyntaxError(
                            f'SyntaxError (line {err_pos[0]}, column {err_pos[1]}): '
                            f'token of kind TokenKind.RSQUAREBRACKET not found.\n'
                            f'>>>{self.file_lines[err_pos[0] - 1].rstrip()}\n'
                            f'>>>{"-" * (err_pos[1] - 1)}^\n')

            # `(` expr `)`
            elif self.check(TokenKind.LROUNDBRACKET):
                self.match(TokenKind.LROUNDBRACKET)

                if self.is_expr_first_set():
                    result = self.parse_expr()
                else:
                    err_pos = self.locate_now()
                    raise SyntaxError(
                        f'SyntaxError (line {err_pos[0]}, column {err_pos[1]}): '
                        f'Expected expression.\n'
                        f'>>>{self.file_lines[err_pos[0] - 1].rstrip()}\n'
                        f'>>>{"-" * (err_pos[1] - 1)}^\n')

                if self.check(TokenKind.RROUNDBRACKET):
                    self.match(TokenKind.RROUNDBRACKET)
                else:
                    err_pos = self.locate_now()
                    raise SyntaxError(
                        f'SyntaxError (line {err_pos[0]}, column {err_pos[1]}): '
                        f'token of kind TokenKind.RROUNDBRACKET not found.\n'
                        f'>>>{self.file_lines[err_pos[0] - 1].rstrip()}\n'
                        f'>>>{"-" * (err_pos[1] - 1)}^\n')
            else:
                raise NotImplementedError(f'Error: parse_cexpr() was not implemented '
                                          f'for {self.lexer.peek()} as next token.')

            # cexpr `[` expr `]`
            while self.check(TokenKind.LSQUAREBRACKET):
                self.match(TokenKind.LSQUAREBRACKET)
                if self.is_expr_first_set():
                    index_expr = self.parse_expr()

                    if self.check(TokenKind.RSQUAREBRACKET):
                        self.match(TokenKind.RSQUAREBRACKET)
                    else:
                        err_pos = self.locate_now()
                        raise SyntaxError(
                            f'SyntaxError (line {err_pos[0]}, column {err_pos[1]}): '
                            f'token of kind TokenKind.RSQUAREBRACKET not found.\n'
                            f'>>>{self.file_lines[err_pos[0] - 1].rstrip()}\n'
                            f'>>>{"-" * (err_pos[1] - 1)}^\n')

                    result = ast.IndexExpr.get(result, index_expr)
                else:
                    err_pos = self.locate_now()
                    raise SyntaxError(
                        f'SyntaxError (line {err_pos[0]}, column {err_pos[1]}): '
                        f'Expected expression.\n'
                        f'>>>{self.file_lines[err_pos[0] - 1].rstrip()}\n'
                        f'>>>{"-" * (err_pos[1] - 1)}^\n')

            return result
        else:
            raise NotImplementedError('Error: parse_cexpr() is used in a wrong place. The first set is not a cexpr.')

    def is_block_first_set(self) -> bool:
        if self.check([TokenKind.NEWLINE, TokenKind.INDENT]):
            return True

        return False

    def parse_block(self) -> List[Operation]:
        stmt_seq = []
        if self.is_block_first_set():
            self.match(TokenKind.NEWLINE)
            self.match(TokenKind.INDENT)

            if self.is_stmt_first_set():
                stmt_seq = self.parse_stmt_seq()

                if self.check(TokenKind.DEDENT):
                    self.match(TokenKind.DEDENT)
                else:
                    if self.check(TokenKind.INDENT):
                        err_pos = self.locate_now(True)
                        raise SyntaxError(
                            f'SyntaxError (line {err_pos[0]}, column {err_pos[1]}): '
                            f'Unexpected indentation.\n'
                            f'>>>{self.file_lines[err_pos[0] - 1].rstrip()}\n'
                            f'>>>{"-" * (err_pos[1] - 1)}^\n')
                    else:
                        err_pos = self.locate_now()
                        raise SyntaxError(
                            f'SyntaxError (line {err_pos[0]}, column {err_pos[1]}): '
                            f'token of kind TokenKind.DEDENT not found.\n'
                            f'>>>{self.file_lines[err_pos[0] - 1].rstrip()}\n'
                            f'>>>{"-" * (err_pos[1] - 1)}^\n')

                if len(stmt_seq) == 0:
                    raise NotImplementedError(f'There must be at least 1 stmt')
                else:
                    return stmt_seq
            else:
                raise NotImplementedError(f'Expecting stmt as next token, '
                                          f'but got {self.lexer.peek()}')
        else:
            raise NotImplementedError('Error: parse_block() is used in a wrong place. The first set is not a cexpr.')

    def is_literal(self) -> bool:
        if self.check(TokenKind.NONE):
            return True
        if self.check(TokenKind.TRUE):
            return True
        if self.check(TokenKind.FALSE):
            return True
        if self.check(TokenKind.INTEGER):
            return True
        if self.check(TokenKind.STRING):
            return True

        return False

    def parse_literal(self) -> Operation:
        if self.check(TokenKind.NONE):
            self.match(TokenKind.NONE)
            return ast.Literal.get(None)
        if self.check(TokenKind.TRUE):
            self.match(TokenKind.TRUE)
            return ast.Literal.get(True)
        if self.check(TokenKind.FALSE):
            self.match(TokenKind.FALSE)
            return ast.Literal.get(False)
        if self.check(TokenKind.INTEGER):
            integer_token = self.match(TokenKind.INTEGER)
            return ast.Literal.get(integer_token.value)
        if self.check(TokenKind.STRING):
            string_token = self.match(TokenKind.STRING)
            return ast.Literal.get(string_token.value)

        raise NotImplementedError('Error: parse_literal() is used in a wrong place. The next token is not a literal.')

    def is_bin_op(self) -> bool:
        # could be something like this:
        # [TokenKind.PLUS, TokenKind.IDENTIFIER]
        # [TokenKind.PLUS, TokenKind.NONE]
        # [TokenKind.PLUS, TokenKind.TRUE]
        # [TokenKind.PLUS, TokenKind.FALSE]
        # [TokenKind.PLUS, TokenKind.INTEGER]
        # [TokenKind.PLUS, TokenKind.STRING]

        if self.check(TokenKind.PLUS):
            return True
        if self.check(TokenKind.MINUS):
            return True
        if self.check(TokenKind.MUL):
            return True
        if self.check(TokenKind.DIV):
            return True
        if self.check(TokenKind.MOD):
            return True
        if self.check(TokenKind.EQ):
            return True
        if self.check(TokenKind.NE):
            return True
        if self.check(TokenKind.LE):
            return True
        if self.check(TokenKind.GE):
            return True
        if self.check(TokenKind.LT):
            return True
        if self.check(TokenKind.GT):
            return True
        if self.check(TokenKind.IS):
            return True

        return False

    def parse_bin_op(self) -> str:
        if self.check(TokenKind.PLUS):
            return self.match(TokenKind.PLUS).value
        if self.check(TokenKind.MINUS):
            return self.match(TokenKind.MINUS).value
        if self.check(TokenKind.MUL):
            return self.match(TokenKind.MUL).value
        if self.check(TokenKind.DIV):
            return self.match(TokenKind.DIV).value
        if self.check(TokenKind.MOD):
            return self.match(TokenKind.MOD).value
        if self.check(TokenKind.EQ):
            return self.match(TokenKind.EQ).value
        if self.check(TokenKind.NE):
            return self.match(TokenKind.NE).value
        if self.check(TokenKind.LE):
            return self.match(TokenKind.LE).value
        if self.check(TokenKind.GE):
            return self.match(TokenKind.GE).value
        if self.check(TokenKind.LT):
            return self.match(TokenKind.LT).value
        if self.check(TokenKind.GT):
            return self.match(TokenKind.GT).value
        if self.check(TokenKind.IS):
            return self.match(TokenKind.IS).value

        raise NotImplementedError(f'Unable to recognize the binary operand {self.lexer.peek()}')
